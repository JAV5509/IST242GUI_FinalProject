package Controller;

import Model.Model;
import View.View;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JTextField;

/**
 *
 * @author fred
 */
public class Controller {

    Model model;
    View view;
    public Controller() {
        this.view = null;
        this.model = null;
    }
    public Controller(Model m, View v) {
        model = m;
        view = v;
        view.createHeaders(model.getFpData().getHeaders().size()); //you will use variables in your lab
        view.writeOnHeaders(model.getFpData().getHeaders()); //you will use variables in your lab

        //how many lines?
        //linesBeingDisplayed?
        //you need a for loop to replace the individual lines
        //How many lines do we need displayed
        //linesbeingdisplayed
        for (int i = 0; i < model.getFpData().getLinesBeingDisplayed(); i++) //you need a for loop to replace the individual lines
        {
            view.createOneLine(model.getFpData().getLine(i).size());
        }

        /*
        view.createOneLine(model.getFpData().getLine(0).size()); //you will use variables in your lab
        view.createOneLine(model.getFpData().getLine(0).size()); //you will use variables in your lab
        view.createOneLine(model.getFpData().getLine(0).size()); //you will use variables in your lab
        view.createOneLine(model.getFpData().getLine(0).size()); //you will use variables in your lab
        view.createOneLine(model.getFpData().getLine(0).size()); //you will use variables in your lab
        view.createOneLine(model.getFpData().getLine(0).size()); //you will use variables in your lab
        view.createOneLine(model.getFpData().getLine(0).size()); //you will use variables in your lab
        view.createOneLine(model.getFpData().getLine(0).size()); //you will use variables in your lab
        view.createOneLine(model.getFpData().getLine(0).size()); //you will use variables in your lab */
        //This will be used to write on the buttons
        //this method is in the view panel
        //for loop here?
        view.writeOnLines(model.getFpData().
                getLines(model.getFpData().getFirstLineToDisplay(), //from what to what | getLines is the key

                        model.getFpData().getLastLineToDisplay())); //from what to what | getLines is the key
        
        this.addListeners();
    }

	private void addListeners() {
		view.getInitialFrame().getInitialPanel().getCp().addMouseWheelListener(
				new MouseWheelListener() {

					@Override
					public void mouseWheelMoved(MouseWheelEvent e) {
						
                                            
                                                /*int unitsToScroll = e.getUnitsToScroll();
						int wheelRotation = e.getWheelRotation();
						if(wheelRotation < 0) {
							//mouse wheel up
							int firstLineToDisplay = model.getFpData().getFirstLineToDisplay() - unitsToScroll;
							if(firstLineToDisplay < 0) {
								firstLineToDisplay = 0;
							}
							model.getFpData().setFirstLineToDisplay(firstLineToDisplay);
						}
						else {
							//mouse wheel up
							int lastLineToDisplay = model.getFpData().getLastLineToDisplay() + unitsToScroll;
							if(lastLineToDisplay > model.getFpData().getPlayers().size() - 1) {
								lastLineToDisplay = model.getFpData().getPlayers().size() - 1;
							}
							model.getFpData().setLastLineToDisplay(lastLineToDisplay);
						}
                                                if(model.getFpData().getFirstLineToDisplay() < 0 ){
                                                    model.getFpData().setFirstLineToDisplay(0);
                                                }
                                                if(model.getFpData().getLastLineToDisplay() >= model.getFpData().getPlayers().size() ){
                                                    model.getFpData().setLastLineToDisplay(model.getFpData().getPlayers().size() - 1);
                                                }
						view.writeOnLines(model.getFpData().
				                getLines(model.getFpData().getFirstLineToDisplay(), //from what to what | getLines is the key

				                        model.getFpData().getLastLineToDisplay())); //from what to what | getLines is the key
*/
                                                
                                                int one = model.getFpData().getFirstLineToDisplay()+ e.getUnitsToScroll();
                                                model.getFpData().setFirstLineToDisplay(one);
                                                view.writeOnLines(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(),model.getFpData().getLastLineToDisplay()));
                                                
                                                
                                                
                                                

					}
				});
                

        for(JButton b1 : view.getInitialFrame().getInitialPanel().getCp().getHeaders()) {
            
            b1.addMouseListener(new MouseListener() {

                public void mouseClicked(MouseEvent mickey) { // Constructor for mouse input, creates using param mickey
                    //resets the header to orginal color once the user interacts with the header
                    for(JButton reset : view.getInitialFrame().getInitialPanel().getCp().getHeaders()) {
                        //Condition that is created to reset the color
                        if(mickey.getSource() == reset) {
                            //value when reset is true
                            reset.setBackground(Color.red);
                            
                            //Syntax similar to previous listener. However designed for sorting this time.
                            model.getFpData().setSortField(Integer.parseInt(reset.getName()));
                            //sorting Fpdata
                            model.getFpData().sort();
                            //Calls met from view refreshcenter
                            view.RefreshCenter(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(),
                                    
                                    model.getFpData().getLastLineToDisplay()), model.getFpData().getHeaders());


                        } 
                        else 
                        {
                            
                            reset.setBackground(Color.gray);
                            
                        }
                    }
                    view.getIframe().getIp().getNp().repaint();
                    
                    view.getIframe().getIp().getNp().updateUI();
                }

                @Override
                public void mousePressed(MouseEvent mickey) {
                }
                @Override
                public void mouseReleased(MouseEvent mickey) {
                }
                @Override
                public void mouseEntered(MouseEvent mickey) {
                }
                @Override
                public void mouseExited(MouseEvent mickey) {
                }
            });
        }
	}
        

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    public View getView() {
        return view;
    }

    public void setView(View view) {
        this.view = view;
    }
        



}
