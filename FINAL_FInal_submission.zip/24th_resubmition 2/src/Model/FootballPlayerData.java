package Model;

import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.ArrayList;

public class FootballPlayerData implements TableData, Displayable, Sortable {

    private ArrayList<TableMember> playas;

    private int firstLineToDisplay;

    private int lineToHighlight;

    private int lastLineToDisplay;

    private int linesBeingDisplayed;
    
    private int fieldToSort = 0;

    public FootballPlayerData() {

        playas = new ArrayList<>();

        this.setFirstLineToDisplay(0);

        this.setLinesBeingDisplayed(20);

        this.setLastLineToDisplay(firstLineToDisplay + linesBeingDisplayed);

        lineToHighlight = 2;

        loadTable();
    }

    @Override
    public void loadTable() {
        ReadPlayersFromXML();
    }

    public void ReadPlayersFromXML() {
        try {
            FootballPlayer fp;
            XMLDecoder decoder;
            decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream("FootballPlayerTable.xml")));
            fp = new FootballPlayer();
            while (fp != null) {
                try {
                    fp = (FootballPlayer) decoder.readObject();
                    playas.add(fp);

                } catch (ArrayIndexOutOfBoundsException theend) {
                    //System.out.println("end of file");
                    break;
                }
            }
            decoder.close();
        } catch (Exception xx) {
            xx.printStackTrace();
        }
    }

    /*
Required Methods:
public void loadTable();(Above)

public ArrayList<TableMember> getTable();

public ArrayList<String> getHeaders();

public ArrayList<String> getLine(int line);

public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine);
     */
//Method 1
    @Override
    public ArrayList<TableMember> getTable() {

        ArrayList<TableMember> tableArr = new ArrayList<>();

        for (int x = 0; x < getPlayers().size(); x++) {

            tableArr.add(getPlayers().get(x));

        }
        return tableArr;
    }

//Method 2
    public ArrayList<String> getHeaders() {

        return new FootballPlayer().getAttributeNames();

    }

//Method 3
    public ArrayList<String> getLine(int line) {

        return playas.get(line).getAttributes();
    }

//Method 4
    public ArrayList<ArrayList<String>> getLines(int one, int two) {

        ArrayList<ArrayList<String>> line = new ArrayList<ArrayList<String>>();

        for (int j = one; j <= two; j++) {

            line.add(getLine(j));
        }

        return line;
    }

    public ArrayList<TableMember> getPlayers() {

        return playas;
    }

    public void setPlayers(ArrayList<TableMember> players) {

        this.playas = players;
    }

    /*
    
    Assignment:
    
    1)Create 8 methods in the FBPlayer Data, 4 get, 4 set. 
           -do first line, last, # lines being displayed, highlighted lines
           -If the last line exceeds the 124 objects available display the number of lines up the last available obj
    2)Implement methods in the displayable interface
    
    Dont forget the keyword OVERRIDE!!!!
    Overide!!
     */
    //Get Methods:
    @Override
    public int getFirstLineToDisplay() {

        return this.firstLineToDisplay;
    }

    @Override
    public int getLastLineToDisplay() {

        return lastLineToDisplay = firstLineToDisplay + linesBeingDisplayed - 1;
    }

    @Override
    public int getLinesBeingDisplayed() {

        return linesBeingDisplayed;

    }

    @Override
    public int getLineToHighlight() {

        return lineToHighlight;
    }

    //Set Methods:
    @Override
    public void setFirstLineToDisplay(int firstLineToDisplay) {
        //if the value entered is less than 0(the first row in table)
        if (firstLineToDisplay < 0) //give firstline the value of 0 which is the index of first object
        {
            firstLineToDisplay = 0;
        }
        else if (firstLineToDisplay>playas.size())
        {
            firstLineToDisplay = playas.size()-linesBeingDisplayed;
        }
        else if (firstLineToDisplay>playas.size()-linesBeingDisplayed)
        {
            firstLineToDisplay = playas.size()-linesBeingDisplayed;
        }
        //condition if the value is greater than the number of obj's available
//        if (firstLineToDisplay > playas.size())
//                firstLineToDisplay = playas.size() - linesBeingDisplayed;

        this.firstLineToDisplay = firstLineToDisplay;
        this.setLastLineToDisplay(firstLineToDisplay+(linesBeingDisplayed-1));

    }

    @Override
    public void setLastLineToDisplay(int lastLineToDisplay) {

        this.lastLineToDisplay = lastLineToDisplay;
        if (lastLineToDisplay>playas.size())
        {
            lastLineToDisplay = playas.size();
        }

    }

    @Override
    public void setLinesBeingDisplayed(int linesBeingDisplayed) {

        this.linesBeingDisplayed = linesBeingDisplayed;
    }

    @Override
    public void setLineToHighlight(int lineToHighlight) {

        this.lineToHighlight = lineToHighlight;
    }
    @Override
    public void sort() {
        
        TableSort sorter = new TableSort(); // Creates obj tablesort from the interface
        //Creates a var called playas, its value is plays and field to sort, sorted
        playas = sorter.sortPlayerByField(playas, fieldToSort);
    }
    @Override
    public int getSortField() {
        return fieldToSort;
    }
    @Override
    public void setSortField(int sortField) {
        fieldToSort = sortField;
    }

}
