/**
 * COPYRIGHT(C) 2022 JULIAN VAZQUEZ. ALL RIGHTS RESERVED. Application
 * that returns person objects based on index. Lab01_B HOMEWORK ASSIGNMENT JAVA 17
 */
package Model;

public class Person {

    //bring the contents of your Person class from the first assignment
    //DECLARING THE DATA TYPES OF THE OBJECTS
    private String name;
    private int weight;
    private String hometown;
    private String highSchool;
    private Height height;

    //Constructor that takes no parameters
    public Person() {
        name = ("");
        //setName("");
        weight = 0;
        //setWeight(0);
        hometown = ("N/A");
        //setHometown("N/A");
        highSchool = ("N/A");
        //setHighSchool("N/A");

        height = new Height(0, 0);
    }

    //Constructor that takes parameters AND ASSIGNS THEM
    public Person(String fullname, int currentWeight, String homeCity, String formerHS, Height length) {
        name = fullname;
        //this.setName(fullname);
        weight = currentWeight;
        //this.setWeight(currentWeight);
        hometown = homeCity;
        //this.setHometown(homeCity);
        highSchool = formerHS;
        //this.setHighSchool(formerHS);
        height = length;

    }

    @Override
    public String toString() {

        return this.name + ";" + this.weight + ";" + this.hometown + ";" + this.highSchool + ";" + this.height + ";";

    }

    //Encapsulation allows us to hide all the class variable and let the user have access only to methods that update
    //and release information about the class variables
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getHometown() {
        return hometown;
    }

    public void setHometown(String hometown) {
        this.hometown = hometown;
    }

    public String getHighSchool() {
        return highSchool;
    }

    public void setHighSchool(String highSchool) {
        this.highSchool = highSchool;
    }

    public Height getHeight() {
        return height;
    }

    public void setHeight(Height height) {
        this.height = height;
    }

}
