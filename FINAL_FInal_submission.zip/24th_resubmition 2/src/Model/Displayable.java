/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Model;

/**
 *
 * @author julianvazquez
 */
public interface Displayable {

    //call the methods that were created in football player data class
    public int getFirstLineToDisplay();

    public int getLineToHighlight();

    public int getLastLineToDisplay();

    public int getLinesBeingDisplayed();

    public void setFirstLineToDisplay(int firstLine);

    public void setLineToHighlight(int highlightedLine);

    public void setLinesBeingDisplayed(int numberOfLines);

    public void setLastLineToDisplay(int lastLine);

}
