/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author julianvazquez
 */
public class TableSort {
    
    protected TableSort() {
    }
    
    public ArrayList<TableMember> sortPlayerByField(ArrayList<TableMember> players, int sortField) {
        
        Collections.sort(players, getComparator(sortField));
        
        return players;
    }
// Create COmparator for sorting, takes param
    public Comparator<TableMember> getComparator(int sortParam) {

        Comparator<TableMember> returnValues;
        //If statement for if the val of sortParam is 0
        if (sortParam == 0) {
            //assigns values to return values
            returnValues = (o1, o2) -> {
                
                if (Integer.parseInt(o1.getAttribute(0)) < Integer.parseInt(o2.getAttribute(0))){
                    
                    return -1;
                    
                } else if (Integer.parseInt(o1.getAttribute(0)) == Integer.parseInt(o2.getAttribute(0))){
                    
                    return 0;
                    
                } else 
                {
                    
                    return 1;
                }
            };
        } else 
        {
            returnValues = Comparator.comparing(o -> o.getAttribute(sortParam));

        }

        return returnValues;
    }


    
}
