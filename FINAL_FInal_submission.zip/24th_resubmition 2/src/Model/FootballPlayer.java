/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author julianvazquez
 */
public class FootballPlayer extends Person implements TableMember {
    //declaring vars for constructors

    private int playerNumber;
    private String position;

    //No parameter constructor is created
    public FootballPlayer() {
        //Inherits values from the superclass Person
        super();
        //Assigning values to variables previously declared
        this.playerNumber = 0; // this is used to call the current value
        this.position = "N/A";
    }

    //Parameter constructor that will eventually inhereit values from Person
    public FootballPlayer(String fullname, int currentWeight, String homeCity, String formerHS, Height length, int playerNumber, String position) {
        //Super calls the variables from SUPER class
        super(fullname, currentWeight, homeCity, formerHS, length);
        this.playerNumber = playerNumber;
        this.position = position;
    }

    @Override
    public String toString() {
        return super.toString() + "  FootballPlayer" + "No. =" + playerNumber + ", POS. =" + position + '}';
    }

    /*
    
    Four neccessary methods:
    
    1 . getAttribute(int n )
    2 . getAttributes( )
    3 . getAttributeName(int n)
    4 . getAttributeNames( )
     */
    // Method 1:
    @Override
    public String getAttribute(int n) {

        switch (n) { //Switch is used to compare val
            case 0:

                return String.valueOf(this.playerNumber);// this returns the current value of the variable playerNumber, this is index 0 in the table

            case 1:
                return this.position; //Case 1 , index 1, returns the current value of "position"

            //The super. is used for inheriating values in the Person class
            case 2:
                return super.getName(); // Case 2, index 2 in the table, returns the value of name
            case 3:
                return super.getHeight().toString(); // Index 3 of table
            case 4:
                return String.valueOf(super.getWeight());// index 4 of table
            case 5:
                return super.getHometown();//index 5  of table 
            case 6:
                return super.getHighSchool();//index 6 of table
            default:
                return ("Please enter a different number,OUT OF BOUNDS");// Return statement if a number out of bounds
        }
    }

    //Method No.2
    //Smarter to use arraylist vs arrays.. array has fixed capacity vs a arraylist that can be appended to 
    @Override
    public ArrayList<String> getAttributes() {
        ArrayList<String> attriArr;
        attriArr = new ArrayList<>();

        for (int i = 0; i <= 6; i++) {      //for loop that iterates through up to index 5 thats the no. of values for each obj

            attriArr.add(getAttribute(i));//We use getAttribitue(n) for the value and append to the list for the obj
        }

        return attriArr;

    }

    @Override
    public String getAttributeName(int n) {

        switch (n) {
            case 0:
                return "number";

            case 1:
                return "position";
            case 2:
                return "name";
            case 3:
                return "height";
            case 4:
                return "weight";
            case 5:
                return "hometown";
            case 6:
                return "highSchool";
            default:
                return ("Please enter a different val!");
        }

    }

    @Override
    public ArrayList<String> getAttributeNames() {

        ArrayList<String> getAttriNameList = new ArrayList<>();

        for (int i = 0; i <= 6; i++) {

            getAttriNameList.add(getAttributeName(i));

        }

        return getAttriNameList;
    }

    public int getNumber() {

        return playerNumber;

    }

    public void setNumber(int number) {

        this.playerNumber = number;

    }

    public String getPosition() {

        return position;

    }

    public void setPosition(String position) {

        this.position = position;

    }

}
