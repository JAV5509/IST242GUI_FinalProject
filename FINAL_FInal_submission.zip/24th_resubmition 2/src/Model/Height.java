/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author julianvazquez
 */
public class Height {

    private int feet;
    private int inches;
    private String f;

    //Contructor with parameters
    public Height(int feet, int inches) {
        this.feet = feet;
        this.inches = inches;

        //use a toString method to get the 6'2 format
        //String f = String.valueOf(feet);
        //String i = String.valueOf(inches);
        //String fi = (f("'")b); // How should I go about getting the 5'9 format?
    }

    @Override
    public String toString() {

        return this.feet + "'" + this.inches;

    }

    //Constructor without parameters
    public Height() {
        this.feet = 0;
        this.inches = 0;

    }

    public int getFeet() {
        return feet;
    }

    public void setFeet(int feet) {
        this.feet = feet;
    }

    public int getInches() {
        return inches;
    }

    public void setInches(int inches) {
        this.inches = inches;
    }

    public String getF() {
        return f;
    }

    public void setF(String f) {
        this.f = f;
    }

}
