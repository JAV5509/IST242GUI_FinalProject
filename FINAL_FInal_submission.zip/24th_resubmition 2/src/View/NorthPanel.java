/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import java.awt.GridLayout;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.event.EventListenerList;
import javax.swing.plaf.ComponentUI;

/**
 *
 * @author julianvazquez
 */
public class NorthPanel extends JPanel {
    
    private ArrayList<JButton> headers;
    
    public NorthPanel(){
        
        super(); //Inherits
        
        GridLayout griddy = new GridLayout(1,7); //Creates+set params for the gridlayout
        
        setLayout(griddy); //Sets the layout to the value of griddy
    }

    public ComponentUI getUi() {
        return ui;
    }

    public void setUi(ComponentUI ui) {
        this.ui = ui;
    }

    public EventListenerList getListenerList() {
        return listenerList;
    }

    public void setListenerList(EventListenerList listenerList) {
        this.listenerList = listenerList;
    }
    
    public ArrayList<JButton> getHeaders() {
        return headers;
    }

    public void setButton(ArrayList<JButton> headers) {
        this.headers = headers;
    }
    
}
