package View;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.EventListenerList;

public class CenterPanel extends JPanel {

    ArrayList<JButton> headers;

    ArrayList<ArrayList<JButton>> multipleLines;  //should match with getLines arrayList of ArrayList
    
    Color defaultBackground;
    Color defaultForeground;
    JButton colorButton;

    CenterPanel() {
        super(); //inherit from JP

        headers = new ArrayList<>(); //header arrlist

        multipleLines = new ArrayList<>(); //data arrlist

        this.setBackground(Color.pink);
        
        JButton b = new JButton(); //create a button to get default Background and Foreground
        defaultBackground = b.getBackground();
        defaultForeground = b.getForeground();
    }

    void createHeaders(int size) {
        for (int i = 0; i < size; i++) {
            JButton b1 = new JButton("" + i); //create a buuton

            add(b1); //add it to the screen/panel
            b1.setName(""+i);
 
            headers.add(b1); //add it to the array
            b1.addActionListener(new ActionListener() {
              @Override
              public void actionPerformed(ActionEvent e) {
                if(colorButton != null) {
                  colorButton.setBackground(defaultBackground);
                  colorButton.setForeground(defaultForeground);	
                }
                b1.setBackground(Color.BLACK);
                b1.setForeground(Color.WHITE);
                colorButton = b1;
              }
            });

        }
        this.setLayout(new GridLayout(0, size));

        this.validate();

        this.repaint();
    }

    void writeOnHeaders(ArrayList<String> names) {

        for (int i = 0; i < names.size(); i++) {

            headers.get(i).setText(names.get(i));

        }
    }

    void createLines(int size) {

        ArrayList<JButton> lineButtons = new ArrayList<>(); //one line of buttons

        //add buttons to one line
        for (int j = 0; j < size; j++) {
            JButton b1 = new JButton();//create a buuton

            add(b1);//add it to the screen/panel

            lineButtons.add(b1);//add it to the array
            
            
              

            b1.setText(multipleLines.indexOf(b1) + "");
        }

        multipleLines.add(lineButtons);

        this.setLayout(new GridLayout(0, size));
        this.validate();
        this.repaint();
    }

    void writeOnLines(ArrayList<ArrayList<String>> names) {
        //for each line
        for (int i = 0; i < names.size(); i++) {
            //for line i
            for (int j = 0; j < names.get(i).size(); j++) {
                multipleLines.get(i).get(j).setText(names.get(i).get(j));

            }
        }
    }
    public void displayLines(String j, int row, int col) {

       multipleLines.get(row).get(col).setText(j);
    }

    public ArrayList<JButton> getHeaders() {
        return headers;
    }

    public void setHeaders(ArrayList<JButton> headers) {
        this.headers = headers;
    }

    public ArrayList<ArrayList<JButton>> getJuju() {

        return multipleLines;
    }

    public void setJuju(ArrayList<ArrayList<JButton>> juju) {
        //this.juju = juju;
        this.multipleLines = juju;
    }

    public ArrayList<ArrayList<JButton>> getMultipleLines() {
        return multipleLines;
    }

    public void setMultipleLines(ArrayList<ArrayList<JButton>> multipleLines) {
        this.multipleLines = multipleLines;
    }

    public Color getDefaultBackground() {
        return defaultBackground;
    }

    public void setDefaultBackground(Color defaultBackground) {
        this.defaultBackground = defaultBackground;
    }

    public Color getDefaultForeground() {
        return defaultForeground;
    }

    public void setDefaultForeground(Color defaultForeground) {
        this.defaultForeground = defaultForeground;
    }

    public JButton getColorButton() {
        return colorButton;
    }

    public void setColorButton(JButton colorButton) {
        this.colorButton = colorButton;
    }

    public EventListenerList getListenerList() {
        return listenerList;
    }

    public void setListenerList(EventListenerList listenerList) {
        this.listenerList = listenerList;
    }
    
    
    
}
