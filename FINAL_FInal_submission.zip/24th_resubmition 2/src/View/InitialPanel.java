package View;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;

public class InitialPanel extends JPanel {

    private CenterPanel cp;
    private NorthPanel np;

    public InitialPanel() {
        super();
        BorderLayout bl = new BorderLayout(20, 20);
        setLayout(bl);
        cp = new CenterPanel();
        np = new NorthPanel();
        //   add(np, BorderLayout.NORTH);
        //  add(sp, BorderLayout.SOUTH);
        //   add(wp, BorderLayout.WEST);
        this.setBackground(Color.red);
        add(cp, BorderLayout.CENTER);
        add(cp, BorderLayout.NORTH);
    }

    public NorthPanel getNp() {
        return np;
    }

    public void setNp(NorthPanel np) {
        this.np = np;
    }

    public CenterPanel getCp() {

        return cp;

    }

    public void setCp(CenterPanel cp) {

        this.cp = cp;

    }

}
