//ArrayList<Arraylist> !!!!
package View;

import java.util.ArrayList;
import javax.swing.JButton;

public class View {

    private InitialFrame iframe;

    public View() {
        iframe = new InitialFrame();
    }
    
    public void DisplayNorthButton(String s, int buttonNumber) {
        
        iframe.getInitialPanel().getNp().getHeaders().get(buttonNumber).setText(s);
    }
    
    public void DisplayCenterButton(String j, int row, int col) {
        
        iframe.getInitialPanel().getCp().displayLines(j, row, col);
    }

    public void createHeaders(int size) {
        iframe.getInitialPanel().getCp().createHeaders(size);
    }

    public void writeOnHeaders(ArrayList<String> names) {
        iframe.getInitialPanel().getCp().writeOnHeaders(names);
    }

    public void createOneLine(int size) {
        iframe.getInitialPanel().getCp().createLines(size);
    }

    public void writeOnLines(ArrayList<ArrayList<String>> linedata) {
        iframe.getInitialPanel().getCp().writeOnLines(linedata);
    }

    public InitialFrame getInitialFrame() {
        return iframe;
    }

    public InitialFrame getIframe() {
        return iframe;
    }

    public void setIframe(InitialFrame iframe) {
        this.iframe = iframe;
    }
    
    public void RefreshCenter(ArrayList<ArrayList<String>> lineData, ArrayList<String> headerData) {
            
        for (int j = 0; j < headerData.size(); j++) { //For loop that iterates up to the size of headerdata, condition
            
            iframe.getInitialPanel().getCp().getHeaders().get(j).setText(headerData.get(j));//Event of forloop
        }
        for (int line = 0; line < lineData.size(); line++) {
            
            for (int column = 0; column < lineData.get(line).size(); column++) {
                
                JButton btn = iframe.getInitialPanel().getCp().getJuju().get(line).get(column);
                
                if (btn != null) {
                    
                    iframe.getInitialPanel().getCp().getJuju().get(line).get(column).setText(lineData.get(line).get(column));
                }
            }
        }
    }

}
